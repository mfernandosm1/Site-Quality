// main.js — versão estável para GitHub Pages e localhost
document.addEventListener("DOMContentLoaded", async () => {
  console.log("🚀 Iniciando carregamento global...");

  // Detecta caminho base automaticamente (funciona em subpáginas e no index)
  const base = window.location.pathname.includes("/Site-Quality/")
    ? "/Site-Quality"
    : "";

  // ----------------------------
  // Carregar HEADER
  // ----------------------------
  const headerContainer = document.getElementById("header");
  if (headerContainer) {
    try {
      const res = await fetch(`${base}/header.html`, { cache: "no-store" });
      if (res.ok) {
        headerContainer.innerHTML = await res.text();
        console.log("✅ Header carregado");
        setTimeout(() => {
          initHeaderEvents();
          console.log("🔁 Eventos do menu reanexados após recarregar");
        }, 100);
      } else {
        console.warn("⚠️ Header não encontrado:", res.status);
      }
    } catch (e) {
      console.error("❌ Erro ao carregar header:", e);
    }
  }

  // ----------------------------
  // Carregar FOOTER
  // ----------------------------
  const footerContainer = document.getElementById("footer");
  if (footerContainer) {
    try {
      const res = await fetch(`${base}/footer.html`, { cache: "no-store" });
      if (res.ok) {
        footerContainer.innerHTML = await res.text();
        console.log("✅ Footer carregado");
      } else {
        console.warn("⚠️ Footer não encontrado:", res.status);
      }
    } catch (e) {
      console.error("❌ Erro ao carregar footer:", e);
    }
  }

  // ----------------------------
  // Inicializar Swiper (banners)
  // ----------------------------
  if (typeof Swiper !== "undefined") {
    new Swiper(".swiper", {
      loop: true,
      autoplay: { delay: 5000, disableOnInteraction: false },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      effect: "slide",
    });
    console.log("✅ Swiper inicializado");
  }
});

// ----------------------------
// Eventos do Header / Menu Mobile
// ----------------------------
function initHeaderEvents() {
  const toggle = document.getElementById("menu-toggle");
  const closeBtn = document.getElementById("menu-close");
  const sidebar = document.getElementById("mobile-menu");
  const overlay = document.getElementById("menu-overlay");

  if (!toggle || !sidebar) {
    console.warn("⚠️ Elementos do menu não encontrados.");
    return;
  }

  const open = () => {
    sidebar.classList.add("open");
    overlay?.classList.add("active");
    document.body.classList.add("menu-open");
  };

  const close = () => {
    sidebar.classList.remove("open");
    overlay?.classList.remove("active");
    document.body.classList.remove("menu-open");
  };

  toggle.addEventListener("click", (e) => {
    e.preventDefault();
    sidebar.classList.contains("open") ? close() : open();
  });

  closeBtn?.addEventListener("click", close);
  overlay?.addEventListener("click", close);
  document.addEventListener("keydown", (e) => e.key === "Escape" && close());

  // Fecha o menu ao clicar num link
  document.querySelectorAll(".mobile-nav a").forEach((a) => {
    a.addEventListener("click", close);
  });

  console.log("✅ Eventos do header inicializados");
}
