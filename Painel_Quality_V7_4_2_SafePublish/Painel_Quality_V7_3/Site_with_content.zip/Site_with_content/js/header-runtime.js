(function(){
  function ready(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  ready(async function(){
    try {
      var hasHeader = document.querySelector('header');
      if(!hasHeader && !window.__panelHeaderInjected){
        var res = await fetch('header.html', { cache: 'no-store' });
        if(res.ok){
          var html = await res.text();
          var wrap = document.createElement('div');
          wrap.innerHTML = html;
          document.body.insertBefore(wrap, document.body.firstChild);
          window.__panelHeaderInjected = true;
          console.log('✅ Header carregado');
        }
      }
    } catch(e){ console.warn('[header-runtime] erro:', e); }
  });
})();