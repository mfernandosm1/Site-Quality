// Aguarda DOM estar pronto
document.addEventListener("DOMContentLoaded", () => {
  // Carregar header
  const headerContainer = document.getElementById("header");
  if (headerContainer) {
    fetch("header.html")
      .then(res => res.text())
      .then(data => {
        headerContainer.innerHTML = data;
        initHeaderEvents(); // ativa eventos do header
      });
  }

  // Carregar footer
  const footerContainer = document.getElementById("footer");
  if (footerContainer) {
    fetch("footer.html")
      .then(res => res.text())
      .then(data => {
        footerContainer.innerHTML = data;
      });
  }

  // Iniciar carrossel de banners
  initSwiper();
});

// ----------------------------
// Eventos do Header
// ----------------------------
function initHeaderEvents() {
  const menuToggle = document.getElementById("menu-toggle");
  const menuClose = document.getElementById("menu-close");
  const mobileMenu = document.getElementById("mobile-menu");
  const overlay = document.getElementById("menu-overlay");

  if (!menuToggle || !menuClose || !mobileMenu) {
    console.warn("⚠️ Elementos do menu não encontrados.");
    return;
  }

  const openMenu = () => {
    mobileMenu.classList.add("open");
    mobileMenu.setAttribute("aria-hidden", "false");
    overlay?.classList.add("active");
  };

  const closeMenu = () => {
    mobileMenu.classList.remove("open");
    mobileMenu.setAttribute("aria-hidden", "true");
    overlay?.classList.remove("active");
  };

  menuToggle.addEventListener("click", openMenu);
  menuClose.addEventListener("click", closeMenu);
  overlay?.addEventListener("click", closeMenu);

  // Fechar ao clicar em link
  document.querySelectorAll("#mobile-menu .mobile-nav a").forEach(link => {
    link.addEventListener("click", closeMenu);
  });

  // ----------------------------
  // Busca desktop
  // ----------------------------
  const searchInput = document.getElementById("search-input");
  const searchBtn = document.getElementById("search-button");

  if (searchBtn && searchInput) {
    searchBtn.addEventListener("click", () => doSearch(searchInput.value));
    searchInput.addEventListener("keypress", e => {
      if (e.key === "Enter") doSearch(searchInput.value);
    });
  }

  // ----------------------------
  // Busca mobile
  // ----------------------------
  const searchInputMob = document.getElementById("search-input-mobile");
  const searchBtnMob = document.getElementById("search-button-mobile");

  if (searchBtnMob && searchInputMob) {
    searchBtnMob.addEventListener("click", () => {
      doSearch(searchInputMob.value);
      closeMenu();
    });
    searchInputMob.addEventListener("keypress", e => {
      if (e.key === "Enter") {
        doSearch(searchInputMob.value);
        closeMenu();
      }
    });
  }

  // ----------------------------
  // 🆕 Corrigir busca ao reinjetar header (garante que eventos se liguem mesmo após reload)
  // ----------------------------
  setTimeout(() => {
    const searchBtn2 = document.querySelectorAll("#search-button, #search-button-mobile");
    searchBtn2.forEach(btn => {
      btn.addEventListener("click", () => {
        const input = btn.previousElementSibling;
        if (input && input.value) doSearch(input.value);
      });
    });
  }, 500);

  console.log("✅ Eventos do header inicializados");
}

// ----------------------------
// Lógica de busca simples
// ----------------------------
function doSearch(query) {
  const products = document.querySelectorAll(".product-card");
  const noResults = document.getElementById("no-results");
  if (!products.length) return;

  if (!query || query.trim() === "") {
    products.forEach(p => (p.style.display = "flex"));
    if (noResults) noResults.style.display = "none";
    return;
  }

  let found = false;
  products.forEach(card => {
    const title = card.querySelector("h3")?.textContent?.toLowerCase() || "";
    if (title.includes(query.toLowerCase())) {
      card.style.display = "flex";
      found = true;
    } else {
      card.style.display = "none";
    }
  });

  if (noResults) noResults.style.display = found ? "none" : "block";
}

// ----------------------------
// Swiper - Carrossel de Banners
// ----------------------------
function initSwiper() {
  new Swiper(".swiper", {
    loop: true,
    autoplay: { delay: 5000, disableOnInteraction: false },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    effect: "slide",
  });
}
